const String appName='Ashique Admin';
const String appLogo='assets/logo/logo.gif';
const String appVersion='1.0.0';