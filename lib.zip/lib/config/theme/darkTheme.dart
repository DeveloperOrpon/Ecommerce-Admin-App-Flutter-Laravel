import 'package:flex_color_scheme/flex_color_scheme.dart';

var darkTheme=FlexThemeData.dark(scheme: FlexScheme.mandyRed);