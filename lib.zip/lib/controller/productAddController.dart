import 'package:get/get.dart';

class ProductAddController extends GetxController {
  Rx<Map<String, dynamic>> pickColors = Rx<Map<String, dynamic>>({});
  RxList sizeList=RxList([]);
}
